/*
 * graficos.c
 *
 *  Created on: Sep 4, 2024
 *      Author: Pablo Mazariegos
 */

#include "pgmspace.h"

#include "bitmaps.h"   // <- ya declara 'extern const uint8_t fondo[];'

//const unsigned char fondo [] PROGMEM ={
